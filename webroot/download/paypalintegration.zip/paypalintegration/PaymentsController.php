<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;

/**
 * Salesoptions Controller
 *
 * @property \Manager\Model\Table\SalesoptionsTable $Salesoptions
 */
class PaymentsController extends AppController
{


    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
     
    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
          $this->Auth->allow();
          $this->set('setstate', 'activity');
        
        $this->viewBuilder()->layout('frontend');
        
        define('SANDBOX', 0);
        define('SENDMAIL', 1);
        define('LOGIT', 1);

    }
    
    public function isAuthorized($user)
    {
        
         return parent::isAuthorized($user);
    }
    
            public function index()
    {
        
        if(is_null($this->Auth->user('id'))) {
            $this->Flash->error(__('Please login to access this page.'));
            return $this->redirect(['plugin' => null, 'controller' => 'users', 'action' => 'login']);
        } else {
            $user_id = $this->Auth->user('id');
        }
        
        $payments = $this->Payments->find('all', [ 
            'conditions' => ['user_id' => $user_id]
        ]);
        
        $payments = $this->paginate($payments);

        $this->set(compact('payments'));
        $this->set('_serialize', ['payments']);
    }
    
          public function membership()
    {  
      
        if(is_null($this->Auth->user('id'))) {
            $this->Flash->error(__('Please login to access this page.'));
            return $this->redirect(['plugin' => null, 'controller' => 'users', 'action' => 'login']);
        } else {
            $user_id = $this->Auth->user('id');
        }
        
          $discountapplied = 'no';
        
          $this->loadModel('Salesoptions');
          $salesoptions = $this->Salesoptions->find('all',['conditions'=>['Salesoptions.promocode'=>'verify']]);
          $salesoption = $salesoptions->first();
     
        
      if ($this->request->is('post')) {
      
          $slug = $this->request->data('dothis');
          $promocode = $this->request->data('promocode');
          
          if(!empty($promocode)) {
          
            $this->loadModel('Salesoptions');
            $salesoptions = $this->Salesoptions->find('all',['conditions'=>['Salesoptions.promocode'=>$promocode]]);
            $salesoption = $salesoptions->first();
                
            
            if(!empty($salesoption)) {
                
                $updatedprice = $salesoption->discounted;
                $discountapplied = 'yes';

                $discount = $salesoption->discount;
                if($discount > 0) {
                    $this->Flash->success(__('Promo code has been applied.'));
                }                
                                
            } else {
              $this->Flash->error(__('Promo code has not been applied.'));
            }
        

            $this->set('discount', $discount);
            $this->set('updatedprice', $updatedprice);

            
          }
      }    

        $this->set('encrypted', $salesoption->encrypted);
        $this->set('discountapplied', $discountapplied);
      
    }  
    
      public function subscribe($encrypted)
    {  
      
        if(is_null($this->Auth->user('id'))) {
            $this->Flash->error(__('Please login to access this page.'));
            return $this->redirect(['plugin' => null, 'controller' => 'users', 'action' => 'login']);
        } else {
            $user_id = $this->Auth->user('id');
        }
        

        $this->loadModel('Salesoptions');
        $salesoptions = $this->Salesoptions->find('all',['conditions'=>['Salesoptions.encrypted'=>$encrypted]]);
        $salesoption = $salesoptions->first();
        
        if(empty($salesoption->id)){
            $this->Flash->error(__('Sorry, this option does not exist.'));
            return $this->redirect($this->referer());
        }
                
        $custom = $salesoption->promocode.'_'.$user_id;
    
            $settings = [
            'cmd' => '_xclick-subscriptions',
            'business' => FROM_DEFAULT_EMAIL,
            'item_name' => $salesoption->name,
            'item_number' => $salesoption->id,       
            'currency_code' => 'USD',
            'a3' => $salesoption->discounted,
            //'a3' => $salesoption->price,
            'p3' => '1',
            't3' => 'Y',
            'src' => 1,
            'srt' => 52,
            'sra' => 1,
            'return_url' => DOMAIN.'/payments/paypalreturn',
            'cancel_url' => DOMAIN.'/payments/paypalcancel',
            'notify_url' => DOMAIN.'/payments/notify',
            'custom' => $custom
        ];
        
        if(SANDBOX == 0){
          $settings['sandbox'] = false;
        } else {
          $settings['sandbox'] = true;
        }
          
          $this->loadComponent('Paypal');

        if(LOGIT == 1){
            $this->log('subscribe- > settings' , 'debug');
            $this->log($settings , 'debug');
        }
                         
          $paypal = $this->Paypal->activate($settings);
          
      
    }

   
           public function credit($slug = null)
    {  
        
        if(is_null($this->Auth->user('id'))) {
            $this->Flash->error(__('Please login to access this page.'));
            return $this->redirect(['plugin' => null, 'controller' => 'users', 'action' => 'login']);
        } else {
            $user_id = $this->Auth->user('id');
        }
        
        
        
        $this->loadModel('Salesoptions');
        $salesoptions = $this->Salesoptions->find('all',['conditions'=>['Salesoptions.promocode'=>$slug]]);
        $salesoptions = $salesoptions->first();
        
        if(empty($salesoptions->id)){
            $this->Flash->error(__('Sorry, this option does not exist.'));
            return $this->redirect($this->referer());
        }
        
        $this->set('salesoptions', $salesoptions);
        
        
        $custom = $salesoptions->promocode.'_'.$user_id;
        
                                  
        $settings = [
            'cmd' => '_xclick',
            'business' => FROM_DEFAULT_EMAIL,
            'lc' => 'US',
            'item_name' => $salesoptions->name,
            'item_number' => $salesoptions->id,
            'amount' => $salesoptions->price,
            'currency_code' => 'USD',
            'button_subtype' => 'services',
            'no_note' => '0',
            'tax_rate' => '0.000',
            'shipping' => '0.00',
            'bn' => 'PP-BuyNowBF:btn_buynowCC_LG.gif:NonHostedGuest',
            'first_name' => $this->Auth->user('firstname'),
            'last_name' => $this->Auth->user('lastname'),
            'payer_email' => $this->Auth->user('email'),
            'return_url' => DOMAIN.'/payments/paypalreturn',
            'cancel_url' => DOMAIN.'/payments/paypalcancel',
            'notify_url' => DOMAIN.'/payments/notify',
            'custom' => $custom
        ];

        
        if(SANDBOX == 0){
          $settings['sandbox'] = false;
        } else {
          $settings['sandbox'] = true;
        }
          
          $this->loadComponent('Paypal');

        if(LOGIT == 1){
            $this->log('credit- > settings' , 'debug');
            $this->log($settings , 'debug');
        }
                         
          $paypal = $this->Paypal->activate($settings);
          
    }
    
    
        public function notify()
    {
      
        if(SANDBOX == 0){
          $settings['sandbox'] = false;
        } else {
          $settings['sandbox'] = true;
        }
            
          $this->loadComponent('Paypal');
          $data = $this->Paypal->response($settings);
        
                 
        if(LOGIT == 1){
            $this->log('notify' , 'debug');
            $this->log($data , 'debug');
        }
        
           
          if ( ($data['amount3'] == NULL) || (empty($data['amount3'])) ) { die('no dice'); } else {
          
              if(LOGIT == 1){ 
                  $this->log('notify -> after array check' , 'debug');
                  $this->log($data , 'debug');
              }
              
              $promocode = '';
              $user_id = '';        
              
              $custom = $data['custom'];
              $explode = explode('_', $custom);
              
              $promocode = $explode[0];
              $data['promocode'] = $promocode;
              
              $user_id = $explode[1];
              
              $Table = TableRegistry::get('payments');
              $payment = $Table->newEntity();
              
              $payment->item_name = $data['item_name'];
              $payment->item_number = $data['item_number'];
              $payment->payment_amount = $data['amount3'];
              $payment->payment_status = $data['payer_status'];
              $payment->payment_currency = $data['mc_currency'];
              $payment->receiver_email = $data['receiver_email'];
              $payment->payer_email = $data['payer_email'];
              $payment->custom = $data['custom'];
              $payment->user_id = $user_id;
              $payment->createdtime = date("Y-m-d H:i:s");
              

              $tablep = TableRegistry::get('paypal_history');
              $raw = $tablep->newEntity();
              
              
              $raw->amount3 = $data['amount3'];
              $raw->address_status = $data['address_status'];
              $raw->recur_times = $data['recur_times'];
              $raw->subscr_date = $data['subscr_date'];
              $raw->payer_id = $data['payer_id'];
              $raw->address_street = $data['address_street'];
              $raw->mc_amount3 = $data['mc_amount3'];
              $raw->address_zip = $data['address_zip'];
              $raw->first_name = $data['first_name'];
              $raw->reattempt = $data['reattempt'];
              $raw->address_country_code = $data['address_country_code'];
              $raw->address_name = $data['address_name'];
              $raw->subscr_id = $data['subscr_id'];
              $raw->custom = $data['custom'];
              $raw->payer_status = $data['payer_status'];
              $raw->business = $data['business'];
              $raw->address_country = $data['address_country'];
              $raw->address_city = $data['address_city'];
              $raw->verify_sign = $data['verify_sign'];
              $raw->payer_email = $data['payer_email'];
              $raw->payer_business_name = $data['payer_business_name'];
              $raw->last_name = $data['last_name'];
              $raw->address_state = $data['address_state'];
              $raw->receiver_email = $data['receiver_email'];
              $raw->recurring = $data['recurring'];
              $raw->txn_type = $data['txn_type'];
              $raw->item_name = $data['item_name'];
              $raw->mc_currency = $data['mc_currency'];
              $raw->item_number = $data['item_number'];
              $raw->residence_country = $data['residence_country'];
              $raw->period3 = $data['period3'];
              $raw->ipn_track_id = $data['ipn_track_id'];
              $raw->createdtime = date("Y-m-d H:i:s");
              $tablep->save($raw);
              


              if(LOGIT == 1){ 
                  $this->log('notify -> payment array' , 'debug');                 
                  $this->log($payment , 'debug');
              }
              
              if(LOGIT == 1){ 
                  $this->log('notify -> raw array' , 'debug');                 
                  $this->log($raw , 'debug');
              }
              
              if ($Table->save($payment)) {
                $this->logsubscription($user_id, $data);
              }          
                
          }

    }  
    
 

     
    public function logsubscription($user_id, $data) {
     
                   
      $this->loadModel('Salesoptions');
      $salesoptions = $this->Salesoptions->find('all',['conditions'=>['Salesoptions.promocode'=>$data['promocode']]]);
      $salesoptions = $salesoptions->first();
      
        if(LOGIT == 1){ 
            $this->log('logsubscription->subscription options' , 'debug');
            $this->log($salesoptions , 'debug');
        }
              
      if(!empty($salesoptions->id)) {
       
          $this->loadModel('Users');

          $user = $this->Users->get($user_id);
          $user->verified = 1;
          $user->verification_date = date("Y-m-d H:i:s");
          
          $this->Users->save($user);

          if(LOGIT == 1){ 
              $this->log('logsubscription->paid' , 'debug');
              $this->log($user , 'debug');
          }

                      
          $keys = array();
          $keys[] = $user->firstname;
          
          $sendvalues = array();
          $sendvalues['to'] = $data['receiver_email'];
          $sendvalues['from'] = FROM_DEFAULT_EMAIL;  
          $sendvalues['keys'] = $keys;
          $sendvalues['templateid'] = 6;
            
          $this->loadComponent('Emailc');                  
          $emailc = $this->Emailc->send_email($sendvalues); 
          
          
          $sponsor = $this->Users->find('all',['conditions'=>['Users.slug'=>$data['promocode']]]);
          $sponsor = $sponsor->first();
          
                  
          $keys = array();
          $keys[] = $sponsor->firstname;
          
          $sendvalues = array();
          $sendvalues['to'] = $sponsor->email;
          $sendvalues['from'] = FROM_DEFAULT_EMAIL;  //non needed
          $sendvalues['keys'] = $keys;
          $sendvalues['templateid'] = 25;
          
          
          $this->loadComponent('Emailc');                  
          $emailc = $this->Emailc->send_email($sendvalues);
              
        
        }            
     
     }

  
 
    
    
    public function paypalreturn()
    {            
            $this->Flash->success(__('Thank you for your payment.'));
          
            if(is_null($this->Auth->user('id'))){
                $this->Flash->success(__('Please login to access this page.'));
                return $this->redirect(['controller' => 'users', 'action' => 'login']);
            }
      
            $user_id = $this->Auth->user('id');
            
            $this->loadModel('Users');
            $users = $this->Users->find('all', ['conditions' => ['id' => $user_id]]);		
            $users = $users->first();

            $this->Auth->setUser($users);

            $this->Flash->success(__('Thank you for your payment, if the account has not been verified automatically wait 30 seconds and refresh.'));
            return $this->redirect(['plugin' => null, 'controller' => 'users', 'action' => 'account']);

    }
    
       
    public function paypalcancel()
    {
    
    }
    
     
}
